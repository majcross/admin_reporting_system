<?php
		// $servername = "localhost";
		// $username = "root";
		// $password = "";
		// $db_name = "exam_final";

		// $conn = mysqli_connect($servername,$username,$password,$db_name);

		// if (!$conn) {
		// 	die("connection failed". mysqli_connect_error());
		// }
		
		define('DB_HOST', 'localhost');
		define('DB_USER', 'root');
		define('DB_PASS', '');
		define('DB_NAME', 'evaluation');


		// define('DB_HOST', 'localhost');
		// define('DB_USER', 'seapmfi2_mneadmin');
		// define('DB_PASS', 'Adminuser123456');
		// define('DB_NAME', 'seapmfi2_evaluation');
?>