<?php
	// Plugin version 4.5.0 
	// Created by Ridwan
	$xyz1 = 'data.seapmfireporting.org/data/init.php';
?>