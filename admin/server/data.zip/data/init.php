<?php
	require_once("function.php");
	require_once("conn.php");
	require_once("database.php");
// 	require_once("target.php");
// 	require_once("salary.php");
	require_once("user.php");
	require_once("base.php");
	// require_once("redirect.php");
	require_once("session.php");

?>